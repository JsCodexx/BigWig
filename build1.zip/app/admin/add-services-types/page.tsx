"use client";

import ServiceTypesManager from "@/components/service-types";

export default function AddServiceTypesPage() {
  return <ServiceTypesManager />;
}

"use client";
import Landing from "@/components/landing/landing";

const Home = () => {
  return (
    <div>
      <Landing />
    </div>
  );
};

export default Home;

/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["ebpmscwwmktnudufncts.supabase.co"], // ✅ Add your Supabase domain
  },
};

module.exports = nextConfig;
